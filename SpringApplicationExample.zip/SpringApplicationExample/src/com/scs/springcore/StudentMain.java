package com.scs.springcore;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class StudentMain {

	public static void main(String[] args) {
		Resource res = new ClassPathResource("applicationContext.xml");
        BeanFactory bf = new XmlBeanFactory(res);
        Student s = (Student)bf.getBean("stu");
        s.setSno(1002);
        s.setSname("Manish Kumar");
        System.out.print(s.getSno() + " "+ s.getSname());
	}

}
