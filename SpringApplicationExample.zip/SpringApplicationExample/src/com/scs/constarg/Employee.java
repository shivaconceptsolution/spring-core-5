package com.scs.constarg;

public class Employee {
   private int empid;
   private String empname;
   Employee()
   {
	   empname = "Ravi Kumar";
   }
   Employee(String empname)
   {
	   this.empname = empname;
   }
   Employee(int empid,String empname)
   {
	   this.empid=empid;
	   this.empname = empname;
   }
   public String toString()
   {
	   return this.empid + " " + this.empname;
   }
}
